﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace MyRTSGame
{
    class GatewayBuilding : Building
    {
        public GatewayBuilding(int xPosition, int yPosition, int health, string factionTeam, string symbolImage)
            : base(xPosition, yPosition, health, factionTeam, symbolImage)
        {

        }

        override public bool deathDestruction()
        {
            if (this.Health <= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        override public string toString()
        {
            string output = "X :" + XPosition + Environment.NewLine
            + "Y :" + YPosition + Environment.NewLine
            + "Health: " + Health + Environment.NewLine
            + "Faction: " + FactionTeam + Environment.NewLine
            + "Symboll: " + SymbolImage + Environment.NewLine;
            return output;
        }

        override public void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;

            try
            {
                // open the file
                outFile = new FileStream(@"Files\GateWayBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);

                // write to the file
                writer.WriteLine(xPosition);
                writer.WriteLine(yPosition);
                writer.WriteLine(health);
                writer.WriteLine(factionTeam);
                writer.WriteLine(symbolImage);

                // close the file
                writer.Close();
                outFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);        // put using System.Diagnostics; at the top
            }
            finally
            {
                if (outFile != null)    // park this for now..
                {
                    outFile.Close();
                    writer.Close();
                }
            }
        }

        public Unit spawnNewUnits()
        {
            return null;
        }
    }
}
