﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using Random = UnityEngine.Random;

namespace MyRTSGame
{
	public class Gameengine : MonoBehaviour
	{
		private Map mapclass = new Map();

		private float mapSpacing = 1.272f;
		public int height;
		public int width;

		// Use this for initialization
		void Start()
		{
			mapclass.initialiseMap();
			unityMapInitilisaion();	
			
			mapclass.constructBuildings();
			unityConstructBuildings();

			StartCoroutine(GameStart());

		}

		IEnumerator GameStart()
		{
			yield return new WaitForSeconds(1);
			
			#region Destruction
			
			var units = GameObject.FindGameObjectsWithTag("Unit");
			var building = GameObject.FindGameObjectsWithTag("Building");

			for (int i = 0; i < units.Length; i++)
			{
				Destroy(units[i]);
			}

			for (int i = 0; i < building.Length; i++)
			{
				Destroy((building[i]));
			}
			
			#endregion


			mapclass.battlefield();

			
			for (int i = 0; i < mapclass.unitsOnMap.Count; i++)
			{
				rules(i);
				Debug.Log("Unit List Count:" + mapclass.unitsOnMap.Count);
				//Debug.Log("Health:" + mapclass.unitsOnMap[i].Health + "  " + i);
			}
			
			mapclass.redraw();
			
			unityConstructBuildings();
			unityUnitConstruction();

			StartCoroutine(GameStart());
		}

		
		
		public void unityMapInitilisaion()
		{
			for (var i = 0; i < width; i++)
			{
				for (var j = 0; j < height; j++)
				{
					int tileCheck = Random.Range(1, 7);

					switch (tileCheck)
					{
						case 1:
							Instantiate(Resources.Load("scifiTile_16"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						case 2:
							Instantiate(Resources.Load("scifiTile_27"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						case 3:
							Instantiate(Resources.Load("scifiTile_28"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						case 4:
							Instantiate(Resources.Load("scifiTile_29"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						case 5:
							Instantiate(Resources.Load("scifiTile_30"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						case 6:
							Instantiate(Resources.Load("scifiTile_42"), new Vector3(i * mapSpacing, j * mapSpacing, 0),
								Quaternion.identity);
							break;
						default:
							break;
					}

				}
			}
		}

		public void unityConstructBuildings()
		{
			Debug.Log(("Number of Buildings: " + mapclass.buildingsOnMap.Count));
			foreach (Building temp in mapclass.buildingsOnMap)
			{
				if (temp != null)
				{
					var buildingType = temp.GetType().ToString();
				
					if (buildingType.Contains("GatewayBuilding"))
					{
						Instantiate(Resources.Load("GateWay"), new Vector3(temp.XPosition*mapSpacing, temp.YPosition*mapSpacing, 0), Quaternion.identity);
					}
					if (buildingType.Contains("FactoryBuilding"))
					{
						Instantiate(Resources.Load("FactoryBuilding"), new Vector3(temp.XPosition*mapSpacing, temp.YPosition*mapSpacing, 0), Quaternion.identity);
					}
					if (buildingType.Contains("ResourceBuilding"))
					{
						Instantiate(Resources.Load("ResourceBuilding"), new Vector3(temp.XPosition*mapSpacing, temp.YPosition*mapSpacing, 0), Quaternion.identity);
					}
				}
			}
		}

		public void unityUnitConstruction()
		{
			Debug.Log("Number of Units: " + mapclass.numberOfUnits.ToString());

			foreach (Unit temp in mapclass.unitsOnMap)
			{
				if (temp != null)
				{
					var unitType = temp.GetType().ToString();
					var xPos = temp.XPosition * mapSpacing;
					var yPos = temp.YPosition * mapSpacing;
					
					if (unitType.Contains("MeleeUnit"))
					{
						if (temp.FactionTeam.Contains("Red"))
						{
							if (temp.Health == 100)
							{
								Instantiate(Resources.Load("Health/RedMelee100"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 75)
							{
								Instantiate(Resources.Load("Health/RedMelee75"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 50)
							{
								Instantiate(Resources.Load("Health/RedMelee50"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else
							{
								Instantiate(Resources.Load("Health/RedMelee25"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
						}
						else
						{
							if (temp.Health == 100)
							{
								Instantiate(Resources.Load("Health/BlueMelee100"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 75)
							{
								Instantiate(Resources.Load("Health/BlueMelee75"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 50)
							{
								Instantiate(Resources.Load("Health/BlueMelee50"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else
							{
								Instantiate(Resources.Load("Health/BlueMelee25"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
						}
					}
					else if (unitType.Contains("RangedUnit"))
					{
						if (temp.FactionTeam.Contains("Red"))
						{
							if (temp.Health == 100)
							{
								Instantiate(Resources.Load("Health/RedRanged100"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 75)
							{
								Instantiate(Resources.Load("Health/RedRanged75"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 50)
							{
								Instantiate(Resources.Load("Health/RedRanged50"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else
							{
								Instantiate(Resources.Load("Health/RedRanged25"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
						}
						else
						{
							if (temp.Health == 100)
							{
								Instantiate(Resources.Load("Health/BlueRanged100"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 75)
							{
								Instantiate(Resources.Load("Health/BlueRanged75"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else if (temp.Health == 50)
							{
								Instantiate(Resources.Load("Health/BlueRanged50"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
							else
							{
								Instantiate(Resources.Load("Health/BlueRanged25"), new Vector3(xPos, yPos, 0), Quaternion.identity);
							}
						}
					}
					else
					{
						if (temp.Health == 100)
						{
							Instantiate(Resources.Load("Health/Neutral100"), new Vector3(xPos, yPos, 0), Quaternion.identity);
						}
						else if (temp.Health == 75)
						{
							Instantiate(Resources.Load("Health/Neutral75"), new Vector3(xPos, yPos, 0), Quaternion.identity);
						}
						else if (temp.Health == 50)
						{
							Instantiate(Resources.Load("Health/Neutral50"), new Vector3(xPos, yPos, 0), Quaternion.identity);
						}
						else
						{
							Instantiate(Resources.Load("Health/Neutral25"), new Vector3(xPos, yPos, 0), Quaternion.identity);
						}
					}
				}
			}
		}
		
		
		
		public void rules(int i)
		{
			int audioSelect = Random.Range(1, 3);
            mapclass.checkHealth();

            #region GateWay Rules
            foreach (Building building in mapclass.buildingsOnMap)
            {
                var buildingType = building.GetType().ToString();
				
                if (inBounds(i, mapclass.unitsOnMap))
                {
                    if (buildingType.Contains("GatewayBuilding"))
                    {
                        if ((mapclass.unitsOnMap[i].XPosition == building.XPosition) && (mapclass.unitsOnMap[i].YPosition == building.YPosition))
                        {
	                        mapclass.unitsOnMap[i].XPosition = Random.Range(0, 19);
	                        mapclass.unitsOnMap[i].YPosition = Random.Range(0, 19);
	                        Debug.Log("Unit has been moved xD" + "Unit " + i);
                        } 
                    }
                }
            }
            #endregion
                
            int currentX = mapclass.unitsOnMap[i].XPosition;
            int currentY = mapclass.unitsOnMap[i].YPosition;

            Unit closestUnit = mapclass.unitsOnMap[i].nearestUnit(mapclass.unitsOnMap);
            Building closestBuilding = mapclass.unitsOnMap[i].nearestBuilding(mapclass.buildingsOnMap);
            

			if (inBounds(i, mapclass.unitsOnMap) && (mapclass.unitsOnMap[i] != null))
			{
				#region Unit basic movement
				if (mapclass.unitsOnMap[i].FactionTeam == "Red")                       //RED BASIC MOVE
				{
					mapclass.unitMove(mapclass.unitsOnMap[i], currentX - 1, currentY);
				}
				else if (mapclass.unitsOnMap[i].FactionTeam == "Blue")                 //BLUE BASIC MOVE
				{
					mapclass.unitMove(mapclass.unitsOnMap[i], currentX + 1, currentY);
				}
				else if (mapclass.unitsOnMap[i].FactionTeam == "Neutral")              //NEUTRAL BASIC MOVE
				{
					mapclass.unitMove(mapclass.unitsOnMap[i], currentX + 1, currentY);
				}
				#endregion

				#region Unit/Building Move and Attack
																		//MOVE TO NEAREST UNIT
				if (closestUnit != null && inBounds(i, mapclass.unitsOnMap))
				{
					if (mapclass.unitsOnMap[i].XPosition < closestUnit.XPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX + 1, currentY);
					}
					if (mapclass.unitsOnMap[i].XPosition > closestUnit.XPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX - 1, currentY);
					}

					if (mapclass.unitsOnMap[i].YPosition < closestUnit.YPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX, currentY + 1);
					}
					if (mapclass.unitsOnMap[i].YPosition > closestUnit.YPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX, currentY - 1);
					}
					
					if (mapclass.unitsOnMap[i].isEnemyInRange(closestUnit))
					{
						mapclass.unitsOnMap[i].combat(closestUnit);
						
						switch (audioSelect)
						{
								case 1:
									FindObjectOfType<AudioManager>().Play("Laser1");
									break;
								case 2:
									FindObjectOfType<AudioManager>().Play("Laser2");
									break;
								case 3:
									FindObjectOfType<AudioManager>().Play("Laser3");
									break;
								default:
									break;
						}
						
						mapclass.checkHealth();
						//closestUnit = mapclass.unitsOnMap[i].nearestUnit(mapclass.unitsOnMap);
					}

					/*try
					{
						Debug.Log("Unit: " + i);
						Debug.Log("Health" + mapclass.unitsOnMap[i].Health + "" + i);
						if (mapclass.unitsOnMap[i].Health == 25)
						{
							mapclass.unitsOnMap[i].move(mapclass.unitsOnMap[i].XPosition, mapclass.unitsOnMap[i].YPosition);
						}
					}
					catch (Exception e)
					{
						Console.WriteLine(e);
						throw;
					}*/

				}
				
				
				if (closestBuilding != null && inBounds(i, mapclass.unitsOnMap))
				{
					if (mapclass.unitsOnMap[i].XPosition < closestBuilding.XPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX + 1, currentY);
					}
					if (mapclass.unitsOnMap[i].XPosition > closestBuilding.XPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX - 1, currentY);
					}

					if (mapclass.unitsOnMap[i].YPosition < closestBuilding.YPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX, currentY + 1);
					}
					if (mapclass.unitsOnMap[i].YPosition > closestBuilding.YPosition)
					{
						mapclass.unitMove(mapclass.unitsOnMap[i], currentX, currentY - 1);
					}

					if (mapclass.unitsOnMap[i].attackRangeBuilding(closestBuilding));
					{
						mapclass.unitsOnMap[i].combatBuilding(closestBuilding);
						mapclass.checkHealth();
						//closestBuilding = mapclass.unitsOnMap[i].nearestBuilding(mapclass.buildingsOnMap);
					}
				}
				
				#endregion
			}        
        }
		
		private bool inBounds (int index, List<Unit> list) 
		{
			return (index >= 0) && (index < list.Count);
		}
	}
	

}

