﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace MyRTSGame
{
    class Map
    {
        public string [,] map = new string[20, 20];
        public List<Unit> unitsOnMap = new List<Unit>();
        public List<Building> buildingsOnMap = new List<Building>();
        
        public int numberOfUnits = 0;  //Used to count number of objects created


        public void initialiseMap()  //When called will start the game with a map with no Units
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = ".";
                }
            }
        }

        public string redraw() //Update the Map with Units
        {
            string output = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    output += map[i, j].PadRight(2);
                }
                output += Environment.NewLine;
            }
            return output;
        }

        public void constructBuildings()
        {
            Random rnd = new Random();

            Building resouceBuilding = new ResourceBuilding(17, 17, 100, "Red", "$", "something", 10, 50);
            map[resouceBuilding.XPosition, resouceBuilding.YPosition] = resouceBuilding.SymbolImage;
            buildingsOnMap.Add(resouceBuilding);

            Building factoryBuilding = new FactoryBuilding(1, 1, 100, "Blue", "@", 55, 50, 50);
            map[factoryBuilding.XPosition, factoryBuilding.YPosition] = factoryBuilding.SymbolImage;
            buildingsOnMap.Add(factoryBuilding);

            Building gatewayBuilding = new GatewayBuilding(rnd.Next(0, (18)), rnd.Next(0, (18)), 100, "none", "%");
            map[gatewayBuilding.XPosition, gatewayBuilding.YPosition] = gatewayBuilding.SymbolImage;
            buildingsOnMap.Add(gatewayBuilding);
        }


        public void battlefield()  //A method to randomly generate a new battle field with random units.
        {
            
            int size = 30;  //Used to genrate the max amount of Units to be created
            Random rnd = new Random();

            if (numberOfUnits < size)
            {
                //if (map[buildingsOnMap[0].XPosition - 1, buildingsOnMap[0].YPosition] == "." && map[buildingsOnMap[1].XPosition + 1, buildingsOnMap[1].YPosition] == ".")
                int unitSelection = rnd.Next(1, 100);
                int teamSelection = rnd.Next(1, 100);

                if ((unitSelection) % 2 == 0)
                {
                    if ((teamSelection) % 2 == 0)
                    {
                        Unit tmp = new MeleeUnit(17 - 1, 17, 100, 1, false, 18, "Red", "M", "Joe");
                        map[tmp.XPosition, tmp.YPosition] = tmp.SymbolImage;
                        unitsOnMap.Add(tmp);
                        numberOfUnits++;
                    }
                    else
                    {
                        Unit tmp = new MeleeUnit(1 + 1, 1, 100, 1, false, 18, "Blue", "m", "Connor");
                        map[tmp.XPosition, tmp.YPosition] = tmp.SymbolImage;
                        unitsOnMap.Add(tmp);
                        numberOfUnits++;
                    }
                }
                else
                {
                    if ((teamSelection) % 2 == 0)
                    {
                        Unit tmp = new RangedUnit(17 - 1, 17, 100, 1, false, 19, "Red", "R", "shalom");
                        map[tmp.XPosition, tmp.YPosition] = tmp.SymbolImage;
                        unitsOnMap.Add(tmp);
                        numberOfUnits++;
                    }
                    else
                    {
                        Unit tmp = new RangedUnit(1 + 1, 1, 100, 1, false, 19, "Blue", "r", "bob");
                        map[tmp.XPosition, tmp.YPosition] = tmp.SymbolImage;
                        unitsOnMap.Add(tmp);
                        numberOfUnits++;
                    }
                }

                Unit n = new NeutralUnit(rnd.Next(0, 18), rnd.Next(0, 18), 100, 1, false, 19, "Neutral", "N", "mushi mush");
                map[n.XPosition, n.YPosition] = n.SymbolImage;
                unitsOnMap.Add(n);
                numberOfUnits++;
            }
        }



        public void unitMove(Unit u, int newX, int newY) //A method to move the unit to a specific position.
        {
            map[(u.XPosition), (u.YPosition)] = ".";
            unitUpdate(u, newX, newY);
            map[(u.XPosition), (u.YPosition)] = u.SymbolImage;
        }

        private void unitUpdate(Unit u, int newX, int newY) //A method to update the position of a specific unit.
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                u.move(newX, newY);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < unitsOnMap.Count; i++)
            {
                if (unitsOnMap[i].isAlive())
                { 
                    map[unitsOnMap[i].XPosition, unitsOnMap[i].YPosition] = ".";
                    unitsOnMap.RemoveAt(i);
                    numberOfUnits--;
                }
            }

            for (int i = 0; i < buildingsOnMap.Count; i++)
            {
                if (buildingsOnMap[i].deathDestruction())
                {
                    map[buildingsOnMap[i].XPosition, buildingsOnMap[i].YPosition] = ".";
                    buildingsOnMap.RemoveAt(i);
                }
            }
        }



        public void inGameEvent()
        {
            foreach (Unit u in unitsOnMap)
            {
                if (u.FactionTeam == "Red" && u.SymbolImage == "M")
                {
                    u.FactionTeam = "Blue";
                    u.SymbolImage = "m";
                    map[u.XPosition, u.YPosition] = u.SymbolImage;
                }
                else if (u.FactionTeam == "Red" && u.SymbolImage == "R")
                {
                    u.FactionTeam = "Blue";
                    u.SymbolImage = "r";
                    map[u.XPosition, u.YPosition] = u.SymbolImage;
                }
                else if (u.FactionTeam == "Blue" && u.SymbolImage == "m")
                {
                    u.FactionTeam = "Red";
                    u.SymbolImage = "M";
                    map[u.XPosition, u.YPosition] = u.SymbolImage;
                }
                else if (u.FactionTeam == "Blue" && u.SymbolImage == "r")
                {
                    u.FactionTeam = "Red";
                    u.SymbolImage = "R";
                    map[u.XPosition, u.YPosition] = u.SymbolImage;
                }
            }

            foreach (Building b in buildingsOnMap)
            {
                if (b.FactionTeam == "Red" && b.SymbolImage == "$")
                {
                    Debug.WriteLine("BUILDING MOVE1");
                    b.FactionTeam = "Blue";
                    b.SymbolImage = "@";
                    map[b.XPosition, b.YPosition] = b.SymbolImage;
                }
                else if (b.FactionTeam == "Blue" && b.SymbolImage == "@")
                {
                    Debug.WriteLine("BUILDING MOVE2");
                    b.FactionTeam = "Red";
                    b.SymbolImage = "$";
                    map[b.XPosition, b.YPosition] = b.SymbolImage;
                }
            }
        }

        public void rules(int i)
        {
            checkHealth();

            #region GateWay Rules
            foreach (Building building in buildingsOnMap)
            {
                var buildingType = building.GetType().ToString();
				
                if (buildingType.Contains("GatewayBuilding"))
                {
                    if (building.SymbolImage == "%")
                    {
                        if ((unitsOnMap[i].XPosition == building.XPosition) && (unitsOnMap[i].YPosition == building.YPosition))
                        {
                            Random rnd = new Random();
                            unitsOnMap[i].XPosition = rnd.Next(0, 19);
                            unitsOnMap[i].YPosition = rnd.Next(0, 19);
                        } 
                    }
                }
            }
            #endregion
                
            int currentX = unitsOnMap[i].XPosition;
            int currentY = unitsOnMap[i].YPosition;

            Unit closestUnit = unitsOnMap[i].nearestUnit(unitsOnMap);
            Building closestBuilding = unitsOnMap[i].nearestBuilding(buildingsOnMap);
            
            if ((closestUnit == null) && (closestBuilding == null))
            {
                battlefield();
                return;
            }
            else
            {
                if ((i >= 0) && (i <= unitsOnMap.Count) && (unitsOnMap[i] != null))
                {
                    #region Unit basic movement
                    if (unitsOnMap[i].FactionTeam == "Red")                       //RED BASIC MOVE
                    {
                        unitMove(unitsOnMap[i], currentX - 1, currentY);
                    }
                    else if (unitsOnMap[i].FactionTeam == "Blue")                 //BLUE BASIC MOVE
                    {
                        unitMove(unitsOnMap[i], currentX + 1, currentY);
                    }
                    else if (unitsOnMap[i].FactionTeam == "Neutral")              //NEUTRAL BASIC MOVE
                    {
                        unitMove(unitsOnMap[i], currentX + 1, currentY);
                    }
                    #endregion
    
                    #region Unit/Building Move and Attack
                                                                            //MOVE TO NEAREST UNIT
                    if (closestUnit != null)
                    {
                        if (unitsOnMap[i].XPosition < closestUnit.XPosition)
                        {
                            unitMove(unitsOnMap[i], currentX + 1, currentY);
                        }
                        if (unitsOnMap[i].XPosition > closestUnit.XPosition)
                        {
                            unitMove(unitsOnMap[i], currentX - 1, currentY);
                        }
    
                        if (unitsOnMap[i].YPosition < closestUnit.YPosition)
                        {
                            unitMove(unitsOnMap[i], currentX, currentY + 1);
                        }
                        if (unitsOnMap[i].YPosition > closestUnit.YPosition)
                        {
                            unitMove(unitsOnMap[i], currentX, currentY - 1);
                        }
                        
                        if (unitsOnMap[i].isEnemyInRange(closestUnit))
                        {
                            unitsOnMap[i].combat(closestUnit);
                            checkHealth();
                            //closestUnit = unitsOnMap[i].nearestUnit(unitsOnMap);
                        }
                        
                        if (unitsOnMap[i].Health <= 25)
                        {
                            unitsOnMap[i].move(unitsOnMap[i].XPosition, unitsOnMap[i].YPosition);
                        }
                    }
                    
                    
                    if (closestBuilding != null)
                    {
                        if (unitsOnMap[i].XPosition < closestBuilding.XPosition)
                        {
                            unitMove(unitsOnMap[i], currentX + 1, currentY);
                        }
                        if (unitsOnMap[i].XPosition > closestBuilding.XPosition)
                        {
                            unitMove(unitsOnMap[i], currentX - 1, currentY);
                        }
    
                        if (unitsOnMap[i].YPosition < closestBuilding.YPosition)
                        {
                            unitMove(unitsOnMap[i], currentX, currentY + 1);
                        }
                        if (unitsOnMap[i].YPosition > closestBuilding.YPosition)
                        {
                            unitMove(unitsOnMap[i], currentX, currentY - 1);
                        }
    
                        if (unitsOnMap[i].attackRangeBuilding(closestBuilding));
                        {
                            unitsOnMap[i].combatBuilding(closestBuilding);
                            checkHealth();
                            //closestBuilding = unitsOnMap[i].nearestBuilding(buildingsOnMap);
                        }
                        
                        if (unitsOnMap[i].Health <= 25)
                        {
                            unitsOnMap[i].move(unitsOnMap[i].XPosition, unitsOnMap[i].YPosition);
                        }
                    }
                    
                    #endregion
                }
            }          
        }

        public string detailsString(int x, int y)
        {
            foreach (Unit u in unitsOnMap)
            {
                if (u.XPosition == x && u.YPosition == y)
                {
                    return u.toString();
                }
            }
            return null;
        }

    }
}
