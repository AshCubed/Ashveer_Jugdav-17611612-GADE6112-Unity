﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace MyRTSGame
{
    class ResourceBuilding : Building
    {
        private string resourceType;
        private int resourcesPerGameTick;
        private int resourcesRemaining;

        private int resources = 0;

        #region Accessors
        public string ResourceType
        {
            get { return resourceType; }
            set { resourceType = value; }
        }

        public int ResourcesPerGameTick
        {
            get { return resourcesPerGameTick; }
            set { resourcesPerGameTick = value; }
        }

        public int ResourcesRemaining
        {
            get { return resourcesRemaining; }
            set { resourcesRemaining = value; }
        }
        #endregion

        public ResourceBuilding(int xPosition, int yPosition, int health, string factionTeam, string symbolImage, string resourceType, int resourcesPerGameTick, int resourcesRemaining)
            : base(xPosition, yPosition, health, factionTeam, symbolImage)
        {

        }

        override public bool deathDestruction()
        {
            if (this.Health <= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        override public string toString()
        {
            string output = "X :" + XPosition + Environment.NewLine
            + "Y :" + YPosition + Environment.NewLine
            + "Health: " + Health + Environment.NewLine
            + "Faction: " + FactionTeam + Environment.NewLine
            + "Symboll: " + SymbolImage + Environment.NewLine
            + "Resource Type: " + ResourceType + Environment.NewLine
            + "Resources Per Game Tick: " + ResourcesPerGameTick + Environment.NewLine
            + "Resources Remaining: " + ResourcesRemaining + Environment.NewLine;
            return output;
        }

        override public void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;

            try
            {
                // open the file
                outFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);

                // write to the file
                writer.WriteLine(xPosition);
                writer.WriteLine(yPosition);
                writer.WriteLine(health);
                writer.WriteLine(factionTeam);
                writer.WriteLine(symbolImage);
                writer.WriteLine(resourceType);
                writer.WriteLine(resourcesPerGameTick);
                writer.WriteLine(resourcesRemaining);

                // close the file
                writer.Close();
                outFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);        // put using System.Diagnostics; at the top
            }
            finally
            {
                if (outFile != null)    // park this for now..
                {
                    outFile.Close();
                    writer.Close();
                }
            }
        }

        public void genResources()
        {
            resources++;
        }

        public void removeResources()
        {
            this.resourcesRemaining--;
        }

    }
}
