﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace MyRTSGame
{
    abstract class Unit
    {
        protected int xPosition;
        protected int yPosition;
        protected int health;
        protected int speed;
        protected bool attack;
        protected int attackRange;
        protected string factionTeam;
        protected string symbolImage;
        protected string name;

        #region Constructors
        public Unit()
        {
            xPosition = 0;
            yPosition = 0;
            health = 0;
            speed = 0;
            attack = false;
            attackRange = 0;
            factionTeam = "";
            symbolImage = "";
            name = "";
        }

        public Unit(int xPosition, int yPosition, int health, int speed, bool attack, int attackRange, string factionTeam, string symbolImage, string name)
        {
            this.xPosition = xPosition;
            this.yPosition = yPosition;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.factionTeam = factionTeam;
            this.symbolImage = symbolImage;
            this.name = name;
        }
        #endregion

        //Destructor
        ~Unit()
        {

        }


        #region Accessors
        public int XPosition
        {
            get { return xPosition; }
            set { xPosition = value; }
        }

        public int YPosition
        {
            get { return yPosition; }
            set { yPosition = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public bool Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public int AttackRange
        {
            get { return attackRange; }
            set { attackRange = value; }
        }

        public string FactionTeam
        {
            get { return factionTeam; }
            set { factionTeam = value; }
        }

        public string SymbolImage
        {
            get { return symbolImage; }
            set { symbolImage = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        #endregion

        public abstract void move(int xPosition, int yPosition); //A method to move to a new position;

        public abstract void combat(Unit enemy); //A method to handle combat with another unit;

        public abstract bool isEnemyInRange(Unit enemy);  //A method to determine whether another unit is within attack range;
        
        public abstract bool attackRangeBuilding(Building B);

        public abstract void combatBuilding(Building B);

        public abstract Building nearestBuilding(List<Building> list);

        public abstract Unit nearestUnit(List<Unit> list); //// A method to return position of the closest other unit to this unit;

        public abstract bool isAlive();  // A method to handle the death/ destruction of this unit;

        public abstract string toString();  //A ToString() method to return a neatly formatted string showing all the unit information.

        public abstract void save(); //To save the information of the map and untis to a text file

    }
}
